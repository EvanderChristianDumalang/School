package com.example.pokeapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
