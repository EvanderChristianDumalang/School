import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:flutter_tags/flutter_tags.dart';
import 'package:pokeapp/model/pokemonDetail.dart';

class PokemonDetailPage extends StatelessWidget {
  PokemonDetailPage({Key key, this.pokemonDetail, this.pokemonName})
      : super(key: key);
  final PokemonDetail pokemonDetail;
  final String pokemonName;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(pokemonName),
      ),
      body: ListView(
        children: [
          Container(
            margin: EdgeInsets.only(top: 20),
            child: pokemonDetail.svg == null
                ? Image.network(pokemonDetail.spriteUrl1)
                : SvgPicture.network(pokemonDetail.svg,
                    placeholderBuilder: (BuildContext context) => Container(
                        padding: const EdgeInsets.all(40.0),
                        child: const CircularProgressIndicator()),
                    width: (MediaQuery.of(context).size.width * 0.55),
                    height: (MediaQuery.of(context).size.width * 0.55)),
          ),
          ListTile(
            title: Center(
              child: Text(
                pokemonName,
                style: TextStyle(fontSize: 36, fontWeight: FontWeight.bold),
              ),
            ),
          ),
          Padding(
            padding:
                const EdgeInsets.only(left: 5, right: 5, bottom: 15, top: 5),
            child: Center(
              child: Text('( Species ' + pokemonDetail.species + ' )',
                  style:
                      TextStyle(fontSize: 24, fontWeight: FontWeight.normal)),
            ),
          ),
          Divider(),
          Card(
            margin: EdgeInsets.symmetric(horizontal: 10, vertical: 5),
            elevation: 5,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 15),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  Text('Types',
                      style: TextStyle(
                          fontSize: 24, fontWeight: FontWeight.normal)),
                  Tags(
                    itemCount: pokemonDetail.types.length,
                    itemBuilder: (int index) {
                      var item = pokemonDetail.types[index];
                      return ItemTags(
                          onPressed: (item) => {},
                          onLongPressed: (item) => {},
                          padding:
                              EdgeInsets.symmetric(horizontal: 15, vertical: 5),
                          index: index,
                          title: item,
                          textStyle: TextStyle(
                              fontSize: 16, fontWeight: FontWeight.normal));
                    },
                  )
                ],
              ),
            ),
          ),
          Card(
            margin: EdgeInsets.symmetric(horizontal: 10, vertical: 5),
            elevation: 5,
            child: Padding(
                padding: const EdgeInsets.only(
                    left: 5, right: 5, bottom: 10, top: 10),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    Text(
                        '( Weight ' +
                            (pokemonDetail.weight / 10).toString() +
                            ' kg )',
                        style: TextStyle(
                            fontSize: 18, fontWeight: FontWeight.normal)),
                    Text(
                        '( Height ' +
                            (pokemonDetail.height / 10).toString() +
                            ' m )',
                        style: TextStyle(
                            fontSize: 18, fontWeight: FontWeight.normal)),
                  ],
                )),
          ),
          Card(
            margin: EdgeInsets.symmetric(horizontal: 10, vertical: 5),
            elevation: 5,
            child: Padding(
              padding: const EdgeInsets.only(
                  right: 5, left: 20, top: 15, bottom: 15),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  Padding(
                    padding: const EdgeInsets.only(bottom: 10.0),
                    child: Text('Abilities : ',
                        style: TextStyle(
                            fontSize: 24, fontWeight: FontWeight.normal)),
                  ),
                  Tags(
                    itemCount: pokemonDetail.abilities.length,
                    itemBuilder: (int index) {
                      var item = pokemonDetail.abilities[index];
                      return ItemTags(
                          onPressed: (item) => {},
                          onLongPressed: (item) => {},
                          padding:
                              EdgeInsets.symmetric(horizontal: 15, vertical: 5),
                          index: index,
                          title: item,
                          textStyle: TextStyle(
                              fontSize: 16, fontWeight: FontWeight.normal));
                    },
                  )
                ],
              ),
            ),
          ),
          Card(
            margin: EdgeInsets.symmetric(horizontal: 10, vertical: 5),
            elevation: 5,
            child: Padding(
              padding: const EdgeInsets.only(
                  right: 5, left: 20, top: 15, bottom: 15),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  Padding(
                    padding: const EdgeInsets.only(bottom: 10.0),
                    child: Text('Moves : ',
                        style: TextStyle(
                            fontSize: 24, fontWeight: FontWeight.normal)),
                  ),
                  Tags(
                    itemCount: pokemonDetail.moves.length,
                    itemBuilder: (int index) {
                      var item = pokemonDetail.moves[index];
                      return ItemTags(
                          onPressed: (item) => {},
                          onLongPressed: (item) => {},
                          padding:
                              EdgeInsets.symmetric(horizontal: 15, vertical: 5),
                          index: index,
                          title: item,
                          textStyle: TextStyle(
                              fontSize: 16, fontWeight: FontWeight.normal));
                    },
                  )
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

Widget getMovesWidgets(List<String> strings) {
  List<Widget> list = new List<Widget>();
  list.add(Text('Abilities : ',
      style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)));
  list.add(Divider());
  for (var i = 0; i < strings.length; i++) {
    list.add(Text(strings[i],
        style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)));
  }
  return new Column(children: list);
}
